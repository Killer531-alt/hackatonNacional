// Simulación de la Trazabilidad según la finca seleccionada
function showTraceability() {
    const finca = document.getElementById("fincaSelect").value;
    let traceabilityData = '';

    if (finca === 'finca1') {
        traceabilityData = `
            <h5>Detalles de Trazabilidad para Finca Los Robles:</h5>
            <ul>
                <li><b>Origen:</b> Huila, Colombia</li>
                <li><b>Finca:</b> Finca Los Robles</li>
                <li><b>Proceso:</b> Secado al sol, clasificación por calidad</li>
                <li><b>Transporte:</b> Envío por camión a la planta de procesamiento en Bogotá</li>
            </ul>
        `;
    } else if (finca === 'finca2') {
        traceabilityData = `
            <h5>Detalles de Trazabilidad para Finca La Esperanza:</h5>
            <ul>
                <li><b>Origen:</b> Antioquia, Colombia</li>
                <li><b>Finca:</b> Finca La Esperanza</li>
                <li><b>Proceso:</b> Fermentación controlada, lavado y secado mecánico</li>
                <li><b>Transporte:</b> Envío por tren a Medellín, luego distribución por camión</li>
            </ul>
        `;
    } else if (finca === 'finca3') {
        traceabilityData = `
            <h5>Detalles de Trazabilidad para Finca San Juan:</h5>
            <ul>
                <li><b>Origen:</b> Nariño, Colombia</li>
                <li><b>Finca:</b> Finca San Juan</li>
                <li><b>Proceso:</b> Lavado, secado al sol en patios</li>
                <li><b>Transporte:</b> Envío por camión hasta Pasto, luego distribuido a nivel nacional</li>
            </ul>
        `;
    }

    document.getElementById("traceabilityOutput").innerHTML = traceabilityData;
}

// Simulación de Predicción de Precios
function predictPrices() {
    const predictedPrices = `
        <h5>Predicción de Precios para los Próximos 3 Meses:</h5>
        <ul>
            <li><b>Enero:</b> $1.150 USD por carga</li>
            <li><b>Febrero:</b> $1.180 USD por carga</li>
            <li><b>Marzo:</b> $1.200 USD por carga</li>
        </ul>
    `;
    document.getElementById("predictionOutput").innerHTML = predictedPrices;
}

// Simulación de Optimización Logística
function optimizeLogistics() {
    const optimizedRoutes = `
        <h5>Rutas de Distribución Optimizada:</h5>
        <ul>
            <li><b>Ruta 1:</b> Desde Bogotá a Medellín (Optimización de costos de transporte)</li>
            <li><b>Ruta 2:</b> Desde Medellín a Cali (Optimización de tiempo de entrega)</li>
            <li><b>Ruta 3:</b> Desde Cali a Barranquilla (Minimización de costos y tiempos)</li>
        </ul>
    `;
    document.getElementById("logisticsOutput").innerHTML = optimizedRoutes;
}

// Función para generar el Certificado de Calidad
function generateCertification() {
    const finca = document.getElementById("fincaSelect").value;
    const certificadoInfo = `
        <h5>Certificado de Calidad Generado para la Finca ${finca === 'finca1' ? 'Los Robles' : finca === 'finca2' ? 'La Esperanza' : 'San Juan'}</h5>
        <p><b>Certificado:</b> Café Especial, Calidad Premium</p>
    `;
    document.getElementById("certificadoInfo").innerHTML = certificadoInfo;

    // Generación del código QR
    const qrCodeContainer = document.getElementById("certificadoQRCode");
    qrCodeContainer.innerHTML = ''; // Limpiar el contenedor antes de generar un nuevo QR
    const qrData = `https://certificado.cafe/${finca}`;  // URL para simular el certificado

    QRCode.toCanvas(qrCodeContainer, qrData, function (error) {
        if (error) console.error(error);
    });
}
